package javaSpring.com.verano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeranoApplicationTests {

	@Test
	void contextLoads() {
	}

}
