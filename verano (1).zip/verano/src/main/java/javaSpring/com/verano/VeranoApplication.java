package javaSpring.com.verano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeranoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeranoApplication.class, args);
	}

}
