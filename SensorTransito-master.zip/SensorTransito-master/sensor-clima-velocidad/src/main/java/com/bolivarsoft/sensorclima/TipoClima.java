package com.bolivarsoft.sensorclima;

public enum TipoClima {
    NORMAL,
    LLUVIAS_MODERADAS,
    LLUVIAS_TORRENCIALES
}
