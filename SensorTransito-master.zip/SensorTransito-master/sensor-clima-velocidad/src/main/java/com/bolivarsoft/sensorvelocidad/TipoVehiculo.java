package com.bolivarsoft.sensorvelocidad;

public enum TipoVehiculo {
    Auto,
    Camion,
    Moto,
    Tractor
}
